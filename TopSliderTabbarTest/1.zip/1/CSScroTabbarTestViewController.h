//
//  CSScroTabbarTestViewController.h
//  TopSliderTabbarTest
//
//  Created by pang on 17/1/16.
//  Copyright © 2017年 physoft. All rights reserved.
//

#import "CSScrollerTabbarViewController.h"

@interface CSScroTabbarTestViewController : CSScrollerTabbarViewController

@end
